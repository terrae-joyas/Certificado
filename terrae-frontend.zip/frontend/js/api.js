/**
 * TERRAE — api.js (Fase 3 — Pasaporte Digital Inteligente)
 * -----------------------------------------------------------------------
 * Capa de abstracción ÚNICA para el consumo de datos. Ningún otro archivo
 * JS incrusta datos ni hace fetch() directo: todo pasa por TerraeAPI.
 * Hoy responde con mocks fieles al contrato de datos que el backend
 * FastAPI deberá cumplir (ver docs/FLUJO-DE-DATOS.md y
 * docs/GUIA-INTEGRACION-API.md). Cambiar TERRAE_CONFIG.useMock a false
 * y esto empieza a hablar con la API real sin tocar ningún otro archivo.
 * -----------------------------------------------------------------------
 */

/* global TERRAE_CONFIG, TerraeMocks */

const TerraeAPI = (() => {
  const baseUrl = (window.TERRAE_CONFIG && window.TERRAE_CONFIG.apiBaseUrl) || '/api/v1';
  const useMock = !window.TERRAE_CONFIG || window.TERRAE_CONFIG.useMock !== false;

  let accessTokenEnMemoria = null;
  function setAccessToken(token) { accessTokenEnMemoria = token; }
  function getAccessToken() { return accessTokenEnMemoria; }

  async function solicitar(path, { method = 'GET', body, idempotencyKey, headers = {} } = {}) {
    const url = `${baseUrl}${path}`;
    const cabeceras = { 'Content-Type': 'application/json', ...headers };
    if (accessTokenEnMemoria) cabeceras.Authorization = `Bearer ${accessTokenEnMemoria}`;
    if (idempotencyKey) cabeceras['Idempotency-Key'] = idempotencyKey;

    try {
      const respuesta = await fetch(url, {
        method,
        headers: cabeceras,
        body: body ? JSON.stringify(body) : undefined,
        credentials: 'omit',
      });
      if (!respuesta.ok) {
        const problema = await respuesta.json().catch(() => ({}));
        const error = new Error(problema.detail || `Error ${respuesta.status} al consultar ${path}`);
        error.status = respuesta.status;
        throw error;
      }
      if (respuesta.status === 204) return null;
      return await respuesta.json();
    } catch (error) {
      console.error('[TerraeAPI]', error);
      throw error;
    }
  }

  /* -----------------------------------------------------------------------
     RESOLUCIÓN DE ID DESDE LA URL — soporta ambas rutas exigidas por la
     Fase 3: pieza.html?id=TR-2026-00842  y  /pieza/TR-2026-00842
     En GitHub Pages (hosting estático) la segunda forma requiere que el
     servidor reescriba /pieza/{id} → pieza.html conservando el path
     (ver docs/GUIA-INTEGRACION-API.md, sección "Enrutamiento"). Esta
     función funciona en ambos casos sin cambios.
     ----------------------------------------------------------------------- */
  function resolverIdDesdeUrl() {
    const parametros = new URLSearchParams(window.location.search);
    if (parametros.has('id')) return parametros.get('id');
    if (parametros.has('codigo')) return parametros.get('codigo'); // compatibilidad Fase 2

    const segmentos = window.location.pathname.split('/').filter(Boolean);
    const indicePieza = segmentos.indexOf('pieza');
    if (indicePieza !== -1 && segmentos[indicePieza + 1]) {
      return decodeURIComponent(segmentos[indicePieza + 1]);
    }
    return null;
  }

  /* -----------------------------------------------------------------------
     ENDPOINTS
     ----------------------------------------------------------------------- */
  async function obtenerCatalogo() {
    if (useMock) return TerraeMocks.catalogo;
    return solicitar('/catalogo');
  }

  async function obtenerPasaportePorId(id) {
    if (useMock) return TerraeMocks.pasaporte(id);
    // El backend responde 404 (no encontrada) o 410 (descontinuada/vendida,
    // según campo "motivo") — ver GUIA-INTEGRACION-API.md.
    return solicitar(`/pasaporte/${encodeURIComponent(id)}`);
  }

  async function verificarEstadoBlockchain(id) {
    if (useMock) return TerraeMocks.estadoBlockchain(id);
    return solicitar(`/pasaporte/${encodeURIComponent(id)}/verificar-blockchain`);
  }

  async function obtenerDetalleTecnicoBlockchain(id) {
    if (useMock) return TerraeMocks.detalleTecnicoBlockchain(id);
    return solicitar(`/pasaporte/${encodeURIComponent(id)}/blockchain-tecnico`);
  }

  async function obtenerHistorialMantenimiento(id) {
    if (useMock) return TerraeMocks.historialMantenimiento(id);
    return solicitar(`/joyas/${encodeURIComponent(id)}/mantenimiento`);
  }

  async function registrarMantenimiento(id, datosServicio) {
    if (useMock) return TerraeMocks.mantenimientoRegistrado(id, datosServicio);
    return solicitar(`/joyas/${encodeURIComponent(id)}/mantenimiento`, { method: 'POST', body: datosServicio });
  }

  async function registrarPropietario(id, datosPropietario) {
    if (useMock) return TerraeMocks.propietarioRegistrado(id, datosPropietario);
    return solicitar(`/joyas/${encodeURIComponent(id)}/propietarios`, { method: 'POST', body: datosPropietario });
  }

  async function iniciarSesion(email, password) {
    if (useMock) return TerraeMocks.login(email);
    const resultado = await solicitar('/auth/login', { method: 'POST', body: { email, password } });
    setAccessToken(resultado.access_token);
    return resultado;
  }

  async function registrarJoya(datosJoya, idempotencyKey) {
    if (useMock) return TerraeMocks.joyaCreada(datosJoya);
    return solicitar('/joyas', { method: 'POST', body: datosJoya, idempotencyKey });
  }

  async function aprobarCertificado(joyaId, idempotencyKey) {
    if (useMock) return TerraeMocks.certificadoAprobado(joyaId);
    return solicitar(`/certificados/${joyaId}/aprobar`, { method: 'POST', idempotencyKey });
  }

  return {
    setAccessToken,
    getAccessToken,
    resolverIdDesdeUrl,
    obtenerCatalogo,
    obtenerPasaportePorId,
    verificarEstadoBlockchain,
    obtenerDetalleTecnicoBlockchain,
    obtenerHistorialMantenimiento,
    registrarMantenimiento,
    registrarPropietario,
    iniciarSesion,
    registrarJoya,
    aprobarCertificado,
  };
})();
