/**
 * TERRAE — api.js
 * -----------------------------------------------------------------------
 * Único punto de integración del frontend con el backend FastAPI (Fase 1).
 * NINGÚN otro archivo JS debe usar fetch() directamente contra el backend:
 * todos pasan por TerraeAPI para que, cuando el backend exista, solo haya
 * que configurar TERRAE_CONFIG.apiBaseUrl y este archivo.
 *
 * Hoy (Fase 2) el backend no existe todavía: cada método está implementado
 * y documentado, pero devuelve datos de ejemplo (mock) marcados con
 * "// MOCK —" para que el resto del frontend ya sea funcional en
 * GitHub Pages sin backend. Sustituir el cuerpo mock por el fetch real
 * activando TERRAE_CONFIG.useMock = false cuando exista la API.
 * -----------------------------------------------------------------------
 */

/* global TERRAE_CONFIG */

const TerraeAPI = (() => {
  const baseUrl = (window.TERRAE_CONFIG && window.TERRAE_CONFIG.apiBaseUrl) || '/api/v1';
  const useMock = !window.TERRAE_CONFIG || window.TERRAE_CONFIG.useMock !== false;

  /** Lee el JWT de almacenamiento en memoria de sesión (nunca localStorage
   *  para el access token, por seguridad frente a XSS). */
  let accessTokenEnMemoria = null;

  function setAccessToken(token) {
    accessTokenEnMemoria = token;
  }

  function getAccessToken() {
    return accessTokenEnMemoria;
  }

  /**
   * Wrapper central de fetch con manejo de errores uniforme (RFC 7807),
   * Idempotency-Key opcional y adjunto automático del Bearer token.
   */
  async function solicitar(path, { method = 'GET', body, idempotencyKey, headers = {} } = {}) {
    const url = `${baseUrl}${path}`;
    const cabeceras = {
      'Content-Type': 'application/json',
      ...headers,
    };

    if (accessTokenEnMemoria) {
      cabeceras.Authorization = `Bearer ${accessTokenEnMemoria}`;
    }
    if (idempotencyKey) {
      cabeceras['Idempotency-Key'] = idempotencyKey;
    }

    try {
      const respuesta = await fetch(url, {
        method,
        headers: cabeceras,
        body: body ? JSON.stringify(body) : undefined,
        credentials: 'omit',
      });

      if (!respuesta.ok) {
        const problema = await respuesta.json().catch(() => ({}));
        throw new Error(problema.detail || `Error ${respuesta.status} al consultar ${path}`);
      }

      if (respuesta.status === 204) return null;
      return await respuesta.json();
    } catch (error) {
      console.error('[TerraeAPI]', error);
      throw error;
    }
  }

  /* -----------------------------------------------------------------------
     ENDPOINTS — uno por caso de uso definido en la Fase 1
     ----------------------------------------------------------------------- */

  async function obtenerCatalogo() {
    if (useMock) {
      // MOCK — reemplazar por: return solicitar('/catalogo');
      return TerraeMocks.catalogo;
    }
    return solicitar('/catalogo');
  }

  async function obtenerPasaportePorCodigo(codigoPublico) {
    if (useMock) {
      // MOCK — reemplazar por: return solicitar(`/pasaporte/${codigoPublico}`);
      return TerraeMocks.pasaporte(codigoPublico);
    }
    return solicitar(`/pasaporte/${encodeURIComponent(codigoPublico)}`);
  }

  async function verificarEstadoBlockchain(codigoPublico) {
    if (useMock) {
      // MOCK — reemplazar por: return solicitar(`/pasaporte/${codigoPublico}/verificar-blockchain`);
      return TerraeMocks.estadoBlockchain();
    }
    return solicitar(`/pasaporte/${encodeURIComponent(codigoPublico)}/verificar-blockchain`);
  }

  async function iniciarSesion(email, password) {
    if (useMock) {
      // MOCK — reemplazar por: return solicitar('/auth/login', { method: 'POST', body: { email, password } });
      return TerraeMocks.login(email, password);
    }
    const resultado = await solicitar('/auth/login', { method: 'POST', body: { email, password } });
    setAccessToken(resultado.access_token);
    return resultado;
  }

  async function registrarJoya(datosJoya, idempotencyKey) {
    // Punto de integración futuro: POST /joyas (multipart/form-data para fotos).
    // No implementado en Fase 2 — placeholder documentado.
    if (useMock) return TerraeMocks.joyaCreada(datosJoya);
    return solicitar('/joyas', { method: 'POST', body: datosJoya, idempotencyKey });
  }

  async function aprobarCertificado(joyaId, idempotencyKey) {
    if (useMock) return TerraeMocks.certificadoAprobado(joyaId);
    return solicitar(`/certificados/${joyaId}/aprobar`, { method: 'POST', idempotencyKey });
  }

  async function registrarPropietario(joyaId, datosPropietario) {
    if (useMock) return TerraeMocks.propietarioRegistrado(joyaId, datosPropietario);
    return solicitar(`/joyas/${joyaId}/propietarios`, { method: 'POST', body: datosPropietario });
  }

  async function registrarMantenimiento(joyaId, datosServicio) {
    if (useMock) return TerraeMocks.mantenimientoRegistrado(joyaId, datosServicio);
    return solicitar(`/joyas/${joyaId}/mantenimiento`, { method: 'POST', body: datosServicio });
  }

  return {
    setAccessToken,
    getAccessToken,
    obtenerCatalogo,
    obtenerPasaportePorCodigo,
    verificarEstadoBlockchain,
    iniciarSesion,
    registrarJoya,
    aprobarCertificado,
    registrarPropietario,
    registrarMantenimiento,
  };
})();
