/**
 * TERRAE — passport.js
 * -----------------------------------------------------------------------
 * Controla pieza.html: lee el código público de la URL (?codigo=... o
 * /pasaporte/{codigo} en producción con enrutamiento del backend/CDN),
 * solicita el Pasaporte Digital a TerraeAPI y rellena el DOM.
 * Delega galería a gallery.js, timeline a timeline.js y blockchain a
 * blockchain.js — este archivo solo orquesta el hero y el certificado.
 * -----------------------------------------------------------------------
 */

document.addEventListener('DOMContentLoaded', () => {
  const raiz = document.querySelector('[data-pagina="pasaporte"]');
  if (!raiz) return;

  const codigoPublico = obtenerCodigoDeLaUrl();
  cargarPasaporte(codigoPublico);
});

function obtenerCodigoDeLaUrl() {
  const parametros = new URLSearchParams(window.location.search);
  return parametros.get('codigo') || 'demo-alma-muzo';
}

async function cargarPasaporte(codigoPublico) {
  mostrarEstadoCarga(true);
  try {
    const pasaporte = await TerraeAPI.obtenerPasaportePorCodigo(codigoPublico);
    renderizarHero(pasaporte);
    renderizarCertificado(pasaporte);
    renderizarGarantia(pasaporte.garantia);

    // Notifica a los demás módulos con el pasaporte ya cargado, para que
    // no dupliquen la llamada a la API (single source of truth).
    document.dispatchEvent(new CustomEvent('terrae:pasaporte-cargado', { detail: pasaporte }));
  } catch (error) {
    mostrarErrorPasaporte(error);
  } finally {
    mostrarEstadoCarga(false);
  }
}

function mostrarEstadoCarga(estaCargando) {
  document.querySelectorAll('[data-carga-pasaporte]').forEach((el) => {
    el.classList.toggle('skeleton', estaCargando);
  });
}

function mostrarErrorPasaporte(error) {
  const contenedor = document.querySelector('[data-pasaporte-error]');
  if (contenedor) {
    contenedor.hidden = false;
    contenedor.textContent = 'No fue posible cargar esta pieza. Verifica el código o inténtalo de nuevo más tarde.';
  }
  console.error('[passport.js]', error);
}

function renderizarHero(pasaporte) {
  setTexto('[data-campo="sku"]', pasaporte.sku);
  setTexto('[data-campo="nombre"]', pasaporte.nombre);
  setTexto('[data-campo="metal"]', pasaporte.metal);
  setTexto('[data-campo="peso"]', `${pasaporte.pesoGramos} g`);
  setTexto('[data-campo="origen"]', pasaporte.esmeralda.origenPredicho);
  setTexto('[data-campo="quilates"]', `${pasaporte.esmeralda.quilates} ct`);
  setTexto('[data-campo="color-grado"]', pasaporte.esmeralda.colorGrado);
  setTexto('[data-campo="tratamiento"]', pasaporte.esmeralda.tratamiento);

  const badgeEstado = document.querySelector('[data-campo="badge-estado"]');
  if (badgeEstado) {
    badgeEstado.textContent = pasaporte.estado === 'CERTIFICADA' ? 'Certificada' : 'En proceso';
    badgeEstado.className = `badge ${pasaporte.estado === 'CERTIFICADA' ? 'badge--verificado' : 'badge--pendiente'}`;
  }
}

function renderizarCertificado(pasaporte) {
  const { certificado, blockchain } = pasaporte;
  setTexto('[data-campo="numero-certificado"]', certificado.numeroCertificado);
  setTexto('[data-campo="hash-certificado"]', certificado.hashSha256);
  setTexto('[data-campo="cid-ipfs"]', blockchain.cidIpfs);
  setTexto('[data-campo="tx-hash"]', acortarHash(blockchain.txHash));

  const enlaceTx = document.querySelector('[data-campo="enlace-blockchain"]');
  if (enlaceTx) {
    enlaceTx.href = `${window.TERRAE_CONFIG.blockchainExplorerUrl}${blockchain.txHash}`;
  }

  const enlacePdf = document.querySelector('[data-campo="descargar-pdf"]');
  if (enlacePdf) enlacePdf.href = certificado.urlPdf;

  const fecha = document.querySelector('[data-campo="fecha-emision"]');
  if (fecha) fecha.textContent = new Date(certificado.emitidoEn).toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' });
}

function renderizarGarantia(garantia) {
  if (!garantia) return;
  setTexto('[data-campo="garantia-cobertura"]', garantia.cobertura);
  setTexto('[data-campo="garantia-inicio"]', formatearFecha(garantia.fechaInicio));
  setTexto('[data-campo="garantia-fin"]', formatearFecha(garantia.fechaFin));
}

function setTexto(selector, valor) {
  const el = document.querySelector(selector);
  if (el) el.textContent = valor;
}

function formatearFecha(iso) {
  return new Date(iso).toLocaleDateString('es-CO', { year: 'numeric', month: 'short', day: 'numeric' });
}

function acortarHash(hash) {
  if (!hash) return '';
  return `${hash.slice(0, 10)}…${hash.slice(-8)}`;
}
