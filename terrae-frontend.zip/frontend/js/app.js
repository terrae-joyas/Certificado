/**
 * TERRAE — app.js
 * -----------------------------------------------------------------------
 * Núcleo de la aplicación: configuración global, datos de ejemplo (mocks)
 * y comportamiento común a todas las páginas (navbar, scroll reveal,
 * modales, tabs, año del footer). Se carga en TODAS las páginas, antes
 * que los scripts específicos de cada vista.
 * -----------------------------------------------------------------------
 */

/* -------------------------------------------------------------------------
   CONFIGURACIÓN GLOBAL — único lugar que se toca al conectar el backend real
   ------------------------------------------------------------------------- */
window.TERRAE_CONFIG = {
  apiBaseUrl: 'https://api.terrae.com/api/v1', // Reemplazar por la URL real de FastAPI en Railway
  useMock: true,                                // false cuando el backend de Fase 1 esté desplegado
  nftHabilitado: false,                         // se activa en Fase 6 sin tocar el HTML
  blockchainExplorerUrl: 'https://polygonscan.com/tx/',
};

/* -------------------------------------------------------------------------
   DATOS DE EJEMPLO (MOCKS) — reflejan exactamente los DTOs definidos en
   la Fase 1 (ERD y estructura de APIs), para que integrar el backend real
   sea un cambio de origen de datos, no de forma.
   ------------------------------------------------------------------------- */
const TerraeMocks = {
  catalogo: [
    { sku: 'TRR-AN-001', nombre: 'Alma de Muzo', tipo: 'Anillo', precio: 8900000, imagen: 'assets/img/placeholder-pieza-1.jpg', codigoPublico: 'demo-alma-muzo' },
    { sku: 'TRR-CO-014', nombre: 'Vertiente', tipo: 'Collar', precio: 15400000, imagen: 'assets/img/placeholder-pieza-2.jpg', codigoPublico: 'demo-vertiente' },
    { sku: 'TRR-AR-007', nombre: 'Trifásica', tipo: 'Aretes', precio: 6200000, imagen: 'assets/img/placeholder-pieza-3.jpg', codigoPublico: 'demo-trifasica' },
    { sku: 'TRR-AN-009', nombre: 'Chivor', tipo: 'Anillo', precio: 11200000, imagen: 'assets/img/placeholder-pieza-4.jpg', codigoPublico: 'demo-chivor' },
    { sku: 'TRR-PU-002', nombre: 'Legado', tipo: 'Pulsera', precio: 9800000, imagen: 'assets/img/placeholder-pieza-5.jpg', codigoPublico: 'demo-legado' },
    { sku: 'TRR-CO-021', nombre: 'Tierra Revelada', tipo: 'Collar', precio: 21000000, imagen: 'assets/img/placeholder-pieza-6.jpg', codigoPublico: 'demo-tierra-revelada' },
  ],

  pasaporte(codigoPublico) {
    return {
      codigoPublico,
      sku: 'TRR-AN-001',
      nombre: 'Alma de Muzo',
      tipoPieza: 'Anillo',
      metal: 'Plata 925',
      pesoGramos: 6.4,
      estado: 'CERTIFICADA',
      esmeralda: {
        origenPredicho: 'Muzo',
        confianzaIA: 0.94,
        colorGrado: 'Verde intenso vívido',
        tratamiento: 'Aceite de cedro (menor)',
        quilates: 1.12,
      },
      certificado: {
        numeroCertificado: 'TRR-CERT-2026-000142',
        hashSha256: 'a1f4e9c2b7d3f6a08e1c4b5d9f2a7e3c6b1d8f4a9c2e7b5d1f3a6c9e2b7d4f1a',
        urlPdf: '#',
        estado: 'VERIFICADO',
        emitidoEn: '2026-05-12T10:30:00Z',
      },
      blockchain: {
        txHash: '0x4f2a8c1e9b7d3f6a08e1c4b5d9f2a7e3c6b1d8f4a9c2e7b5d1f3a6c9e2b7d4f1',
        cidIpfs: 'bafybeigdyrztt5o3s6...demo',
        red: 'Polygon Mainnet',
        estado: 'verificado',
      },
      galeria: [
        { tipo: 'foto', url: 'assets/img/placeholder-pieza-1.jpg' },
        { tipo: 'foto', url: 'assets/img/placeholder-detalle-1.jpg' },
        { tipo: 'microscopia', url: 'assets/img/placeholder-microscopia-1.jpg' },
        { tipo: 'foto', url: 'assets/img/placeholder-detalle-2.jpg' },
        { tipo: 'video', url: 'assets/video/placeholder-pieza.mp4' },
      ],
      timeline: [
        { tipo: 'certificacion', fecha: '2026-05-12', titulo: 'Certificado emitido', detalle: 'Aprobado por auditor gemológico COPNIA.' },
        { tipo: 'blockchain', fecha: '2026-05-12', titulo: 'Anclado en blockchain', detalle: 'Registro verificado en Polygon Mainnet.' },
        { tipo: 'propietario', fecha: '2026-05-20', titulo: 'Cambio de propietario', detalle: 'Compra registrada en tienda Bogotá.' },
        { tipo: 'mantenimiento', fecha: '2026-11-03', titulo: 'Limpieza profesional', detalle: 'Servicio realizado en taller autorizado Terrae.' },
      ],
      garantia: { cobertura: 'Reparación y ajuste', fechaInicio: '2026-05-20', fechaFin: '2029-05-20' },
    };
  },

  estadoBlockchain() {
    return { estado: 'verificado', bloque: 58234110, confirmaciones: 412 };
  },

  login(email) {
    return { access_token: 'demo.jwt.token', usuario: { email, rol: 'OPERADOR' } };
  },

  joyaCreada(datos) {
    return { id: 'demo-id', ...datos, estado: 'PENDIENTE_CERTIFICACION' };
  },

  certificadoAprobado(joyaId) {
    return { id: 'demo-cert-id', joyaId, estado: 'EN_PROCESO' };
  },

  propietarioRegistrado(joyaId, datos) {
    return { id: 'demo-prop-id', joyaId, ...datos };
  },

  mantenimientoRegistrado(joyaId, datos) {
    return { id: 'demo-mant-id', joyaId, ...datos };
  },
};

/* -------------------------------------------------------------------------
   INICIALIZACIÓN COMÚN
   ------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  inicializarNavbar();
  inicializarScrollReveal();
  inicializarModales();
  inicializarTabs();
  inicializarAnioFooter();
});

/** Navbar: fondo sólido al hacer scroll + menú hamburguesa en mobile */
function inicializarNavbar() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  const alScrollear = () => {
    navbar.classList.toggle('navbar--solida', window.scrollY > 40);
  };
  alScrollear();
  window.addEventListener('scroll', alScrollear, { passive: true });

  const toggle = navbar.querySelector('.navbar__menu-toggle');
  const links = navbar.querySelector('.navbar__links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const abierto = links.classList.toggle('esta-abierto');
      toggle.setAttribute('aria-expanded', String(abierto));
    });
  }
}

/** Scroll Reveal — IntersectionObserver, respeta prefers-reduced-motion */
function inicializarScrollReveal() {
  const elementos = document.querySelectorAll('.revelar');
  if (!elementos.length) return;

  const prefiereMenosMovimiento = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefiereMenosMovimiento) {
    elementos.forEach((el) => el.classList.add('esta-visible'));
    return;
  }

  const observador = new IntersectionObserver(
    (entradas) => {
      entradas.forEach((entrada) => {
        if (entrada.isIntersecting) {
          entrada.target.classList.add('esta-visible');
          observador.unobserve(entrada.target);
        }
      });
    },
    { threshold: 0.15, rootMargin: '0px 0px -60px 0px' }
  );

  elementos.forEach((el) => observador.observe(el));
}

/** Modales genéricos: [data-modal-abrir="id"] / [data-modal-cerrar] */
function inicializarModales() {
  document.querySelectorAll('[data-modal-abrir]').forEach((boton) => {
    boton.addEventListener('click', () => {
      const modal = document.getElementById(boton.dataset.modalAbrir);
      if (modal) abrirModal(modal);
    });
  });

  document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('click', (evento) => {
      if (evento.target === overlay) cerrarModal(overlay);
    });
    overlay.querySelectorAll('[data-modal-cerrar]').forEach((boton) => {
      boton.addEventListener('click', () => cerrarModal(overlay));
    });
  });

  document.addEventListener('keydown', (evento) => {
    if (evento.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.esta-abierto').forEach(cerrarModal);
    }
  });
}

function abrirModal(overlay) {
  overlay.classList.add('esta-abierto');
  overlay.setAttribute('aria-hidden', 'false');
  const primerFocable = overlay.querySelector('button, a, input, select, textarea');
  if (primerFocable) primerFocable.focus();
}

function cerrarModal(overlay) {
  overlay.classList.remove('esta-abierto');
  overlay.setAttribute('aria-hidden', 'true');
}

/** Tabs accesibles (ARIA tablist/tab/tabpanel) */
function inicializarTabs() {
  document.querySelectorAll('.tabs').forEach((grupo) => {
    const botones = Array.from(grupo.querySelectorAll('.tabs__boton'));
    botones.forEach((boton) => {
      boton.addEventListener('click', () => activarTab(grupo, boton));
      boton.addEventListener('keydown', (evento) => {
        const indice = botones.indexOf(boton);
        if (evento.key === 'ArrowRight') botones[(indice + 1) % botones.length].focus();
        if (evento.key === 'ArrowLeft') botones[(indice - 1 + botones.length) % botones.length].focus();
      });
    });
  });
}

function activarTab(grupo, botonActivo) {
  const contenedorPaneles = grupo.parentElement;
  grupo.querySelectorAll('.tabs__boton').forEach((boton) => {
    boton.setAttribute('aria-selected', String(boton === botonActivo));
  });
  contenedorPaneles.querySelectorAll('.tabs__panel').forEach((panel) => {
    panel.hidden = panel.id !== botonActivo.getAttribute('aria-controls');
  });
}

function inicializarAnioFooter() {
  const el = document.querySelector('[data-anio-actual]');
  if (el) el.textContent = new Date().getFullYear();
}

/** Utilidad compartida de formato de moneda COP */
function formatearCOP(valor) {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(valor);
}
