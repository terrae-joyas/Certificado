/**
 * TERRAE — blockchain.js
 * -----------------------------------------------------------------------
 * Controla el sello de verificación blockchain del Pasaporte Digital:
 * consulta el estado on-chain (GET /pasaporte/{codigo}/verificar-blockchain,
 * ver Fase 1 sección 7.3) y actualiza el badge en tiempo real. También
 * decide si mostrar la sección NFT (oculta por defecto hasta Fase 6).
 * -----------------------------------------------------------------------
 */

document.addEventListener('DOMContentLoaded', () => {
  const sello = document.querySelector('[data-componente="sello-blockchain"]');
  if (sello) {
    document.addEventListener('terrae:pasaporte-cargado', (evento) => {
      verificarYActualizarSello(sello, evento.detail.codigoPublico);
    });
  }

  gestionarVisibilidadNFT();
});

async function verificarYActualizarSello(sello, codigoPublico) {
  sello.dataset.estado = 'verificando';
  setTextoSello(sello, 'Verificando en blockchain…');

  try {
    const resultado = await TerraeAPI.verificarEstadoBlockchain(codigoPublico);
    if (resultado.estado === 'verificado') {
      sello.dataset.estado = 'verificado';
      setTextoSello(sello, `Verificado en blockchain · bloque ${resultado.bloque}`);
    } else {
      sello.dataset.estado = 'pendiente';
      setTextoSello(sello, 'Anclaje en proceso');
    }
  } catch (error) {
    sello.dataset.estado = 'error';
    setTextoSello(sello, 'No fue posible verificar el estado on-chain');
    console.error('[blockchain.js]', error);
  }
}

function setTextoSello(sello, texto) {
  const span = sello.querySelector('[data-sello-texto]');
  if (span) span.textContent = texto;
}

/**
 * La sección NFT permanece con el atributo `hidden` en el HTML por defecto
 * (ver TERRAE-FASE2 requisito: "NFT oculto hasta la Fase correspondiente").
 * Se revela únicamente cuando window.TERRAE_CONFIG.nftHabilitado === true,
 * que el negocio activará en Fase 6 sin tocar ni el HTML ni el backend.
 */
function gestionarVisibilidadNFT() {
  const seccionNFT = document.querySelector('.seccion-nft');
  if (!seccionNFT) return;
  if (window.TERRAE_CONFIG && window.TERRAE_CONFIG.nftHabilitado) {
    seccionNFT.hidden = false;
  }
}
