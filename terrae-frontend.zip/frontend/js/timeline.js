/**
 * TERRAE — timeline.js
 * -----------------------------------------------------------------------
 * Renderiza el componente .timeline dentro de pieza.html a partir del
 * arreglo `timeline` que llega en el Pasaporte Digital (ver ERD Fase 1:
 * combina HISTORIAL_MANTENIMIENTO y PROPIETARIO, más los hitos de
 * CERTIFICADO/BLOCKCHAIN_REGISTRO, ya fusionados y ordenados por el
 * backend en /pasaporte/{codigo}).
 * -----------------------------------------------------------------------
 */

document.addEventListener('DOMContentLoaded', () => {
  const contenedor = document.querySelector('[data-componente="timeline"]');
  if (!contenedor) return;

  document.addEventListener('terrae:pasaporte-cargado', (evento) => {
    renderizarTimeline(contenedor, evento.detail.timeline);
  });
});

function renderizarTimeline(contenedor, eventos) {
  if (!eventos || !eventos.length) {
    contenedor.innerHTML = '<p>Todavía no hay eventos registrados para esta pieza.</p>';
    return;
  }

  const ordenados = [...eventos].sort((a, b) => new Date(b.fecha) - new Date(a.fecha));

  contenedor.innerHTML = ordenados.map((evento) => `
    <li class="timeline__item" data-tipo="${evento.tipo}">
      <span class="timeline__punto" aria-hidden="true"></span>
      <time class="timeline__fecha" datetime="${evento.fecha}">${formatearFechaTimeline(evento.fecha)}</time>
      <p class="timeline__titulo">${evento.titulo}</p>
      <p class="timeline__detalle">${evento.detalle}</p>
    </li>
  `).join('');
}

function formatearFechaTimeline(iso) {
  return new Date(iso).toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' });
}
