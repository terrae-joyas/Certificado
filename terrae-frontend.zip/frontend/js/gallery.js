/**
 * TERRAE — gallery.js
 * -----------------------------------------------------------------------
 * Dos responsabilidades:
 *  1. En index.html: puebla [data-fuente="api"] de la sección Colecciones
 *     con tarjetas de pieza desde TerraeAPI.obtenerCatalogo().
 *  2. En pieza.html: construye la galería de multimedia (foto/video/
 *     microscopía) a partir del evento 'terrae:pasaporte-cargado' emitido
 *     por passport.js, y controla el lightbox accesible.
 * -----------------------------------------------------------------------
 */

document.addEventListener('DOMContentLoaded', () => {
  const grillaColecciones = document.querySelector('[data-componente="colecciones-grid"]');
  if (grillaColecciones) cargarColecciones(grillaColecciones);

  const grillaGaleria = document.querySelector('[data-componente="galeria"]');
  if (grillaGaleria) {
    document.addEventListener('terrae:pasaporte-cargado', (evento) => {
      renderizarGaleria(grillaGaleria, evento.detail.galeria);
    });
  }

  inicializarLightbox();
});

async function cargarColecciones(contenedor) {
  contenedor.setAttribute('aria-busy', 'true');
  try {
    const piezas = await TerraeAPI.obtenerCatalogo();
    contenedor.innerHTML = piezas.map(tarjetaPiezaHTML).join('');
  } catch (error) {
    contenedor.innerHTML = '<p role="alert">No fue posible cargar la colección en este momento.</p>';
    console.error('[gallery.js]', error);
  } finally {
    contenedor.setAttribute('aria-busy', 'false');
  }
}

function tarjetaPiezaHTML(pieza) {
  return `
    <a class="pieza-card card revelar" href="pieza.html?codigo=${encodeURIComponent(pieza.codigoPublico)}">
      <div class="pieza-card__imagen-wrap">
        <img class="pieza-card__imagen" src="${pieza.imagen}" alt="${pieza.nombre}, ${pieza.tipo} Terrae" loading="lazy" width="480" height="600">
      </div>
      <div class="pieza-card__info">
        <span class="pieza-card__nombre">${pieza.nombre}</span>
        <span class="pieza-card__precio">${formatearCOP(pieza.precio)}</span>
      </div>
    </a>`;
}

function renderizarGaleria(contenedor, items) {
  contenedor.innerHTML = items.map((item, indice) => {
    if (item.tipo === 'video') {
      return `
        <div class="galeria__item" data-tipo="video" data-indice="${indice}" role="button" tabindex="0" aria-label="Reproducir video de la pieza">
          <video src="${item.url}" muted preload="metadata"></video>
          <span class="galeria__reproducir" aria-hidden="true">▶</span>
        </div>`;
    }
    const etiqueta = item.tipo === 'microscopia' ? 'Fotografía de microscopía de la esmeralda' : 'Fotografía de la pieza Terrae';
    return `
      <div class="galeria__item" data-tipo="${item.tipo}" data-indice="${indice}" role="button" tabindex="0" aria-label="Ampliar imagen: ${etiqueta}">
        <img src="${item.url}" alt="${etiqueta}" loading="lazy">
      </div>`;
  }).join('');

  contenedor.dataset.items = JSON.stringify(items);
  contenedor.querySelectorAll('.galeria__item').forEach((el) => {
    el.addEventListener('click', () => abrirLightboxEn(items, Number(el.dataset.indice)));
    el.addEventListener('keydown', (evento) => {
      if (evento.key === 'Enter' || evento.key === ' ') {
        evento.preventDefault();
        abrirLightboxEn(items, Number(el.dataset.indice));
      }
    });
  });
}

/* -------------------------------------------------------------------------
   LIGHTBOX
   ------------------------------------------------------------------------- */
let lightboxItems = [];
let lightboxIndiceActual = 0;

function inicializarLightbox() {
  const lightbox = document.querySelector('.lightbox');
  if (!lightbox) return;

  lightbox.querySelector('.lightbox__cerrar')?.addEventListener('click', cerrarLightbox);
  lightbox.querySelector('.lightbox__anterior')?.addEventListener('click', () => moverLightbox(-1));
  lightbox.querySelector('.lightbox__siguiente')?.addEventListener('click', () => moverLightbox(1));
  lightbox.addEventListener('click', (evento) => {
    if (evento.target === lightbox) cerrarLightbox();
  });
  document.addEventListener('keydown', (evento) => {
    if (!lightbox.classList.contains('esta-abierto')) return;
    if (evento.key === 'Escape') cerrarLightbox();
    if (evento.key === 'ArrowRight') moverLightbox(1);
    if (evento.key === 'ArrowLeft') moverLightbox(-1);
  });
}

function abrirLightboxEn(items, indice) {
  lightboxItems = items;
  lightboxIndiceActual = indice;
  const lightbox = document.querySelector('.lightbox');
  if (!lightbox) return;
  renderizarLightboxActual();
  lightbox.classList.add('esta-abierto');
  lightbox.querySelector('.lightbox__cerrar')?.focus();
}

function moverLightbox(delta) {
  lightboxIndiceActual = (lightboxIndiceActual + delta + lightboxItems.length) % lightboxItems.length;
  renderizarLightboxActual();
}

function renderizarLightboxActual() {
  const contenido = document.querySelector('.lightbox__contenido');
  const contador = document.querySelector('.lightbox__contador');
  const item = lightboxItems[lightboxIndiceActual];
  if (!contenido || !item) return;

  contenido.innerHTML = item.tipo === 'video'
    ? `<video src="${item.url}" controls autoplay></video>`
    : `<img src="${item.url}" alt="Vista ampliada, imagen ${lightboxIndiceActual + 1} de ${lightboxItems.length}">`;

  if (contador) contador.textContent = `${lightboxIndiceActual + 1} / ${lightboxItems.length}`;
}

function cerrarLightbox() {
  const lightbox = document.querySelector('.lightbox');
  if (!lightbox) return;
  lightbox.classList.remove('esta-abierto');
  const contenido = document.querySelector('.lightbox__contenido');
  if (contenido) contenido.innerHTML = '';
}
